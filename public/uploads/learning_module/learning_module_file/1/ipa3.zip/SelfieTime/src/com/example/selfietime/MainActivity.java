package com.example.selfietime;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.hardware.Camera;
import android.hardware.Camera.PictureCallback;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.TextView;
import be.hogent.tarsos.dsp.AudioEvent;
import be.hogent.tarsos.dsp.onsets.OnsetHandler;
import be.hogent.tarsos.dsp.onsets.PercussionOnsetDetector;



public class MainActivity extends Activity {
	private static final String TAG = "ERROR";
	//Camera Stuff
	private static Context context;
	private Camera mCamera;
	private CameraPreview mPreview; 
	private Uri picUri;
	private File pictureFile;
	
	//Sound Stuff
	public static final int SAMPLE_RATE = 16000;
	private AudioRecord recorder;
	private boolean mIsRecording;
	private byte[] buffer;
	private be.hogent.tarsos.dsp.AudioFormat tarsosFormat;
	private PercussionOnsetDetector mPercussionOnsetDetector;
	private OnsetHandler clapHandler;
	private TextView clapTextView;
	private Button listenButton;
	private double prevClap; 
	private int timerCount; 
	private String numText;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		// Maybe good to check if device has a camera
		setContentView(R.layout.activity_main);
		context = getApplicationContext();
		clapTextView = (TextView)findViewById(R.id.clap_text);
	
		mIsRecording = false;
		int minBufferSize = AudioRecord.getMinBufferSize(
				SAMPLE_RATE,
				AudioFormat.CHANNEL_IN_MONO,
				AudioFormat.ENCODING_PCM_16BIT);
		System.out.println("int minBufferSize has been set to: " + minBufferSize);
		
		buffer = new byte[minBufferSize];
		recorder = new AudioRecord(
				MediaRecorder.AudioSource.MIC,
				SAMPLE_RATE,
				AudioFormat.CHANNEL_IN_MONO,
				AudioFormat.ENCODING_PCM_16BIT,
				minBufferSize);
		
		clapHandler = new OnsetHandler() {
    		@Override
    		public void handleOnset(double time, double salience) {
    			final double clapTime = time;
    			runOnUiThread(new Runnable() {
    				@Override
    				public void run() {
    					System.out.println("clapHandler has detected a clap!");
    					if (clapTime - prevClap < 1) {
    						System.out.println("claps happened within a second of each other");
    						listenButton.setText("Listen");
    						mIsRecording = false; 
    						timerCount = 3; 
    						
    						final Timer t = new Timer();
    						TimerTask timerTask = new TimerTask() {
    							 public void run() {
    								if (timerCount == 3) {
				    					numText = "Three";
				    				} else if (timerCount == 2) {
				    					numText = "Two";
				    				} else if (timerCount == 1) {
				    					numText = "One";
				    				}
    								runOnUiThread(new Runnable() {
    					    				@Override
    					    				public void run() {
    					    					clapTextView.setText(numText);
    					    				}
    					    		});
    								 System.out.println(timerCount);
    								 if (timerCount == 0) {
    									 System.out.println("about to take picture!! Cheese!");
    									 runOnUiThread(new Runnable() {
     					    				@Override
     					    				public void run() {
     					    					clapTextView.setText("Picture Taken!");
     					    				}
    									 });
    									 mCamera.takePicture(null, null, jpegCallback);
    									 t.cancel();
    								 }
    								 timerCount--;
    							 }
    						};
    						t.scheduleAtFixedRate(timerTask, 1000L, 1000L);
    					} else {
    						System.out.println("claps happened too far apart");
    						prevClap = clapTime;
    					}
    				}
    			});

    		}
    	};
		
		mPercussionOnsetDetector = new PercussionOnsetDetector(
				SAMPLE_RATE,
				(minBufferSize/2),
				0,
				clapHandler);

        listenButton = (Button) findViewById(R.id.button_capture);
        listenButton.setOnClickListener(new View.OnClickListener() {
        	@Override
            public void onClick(View v) {
            	System.out.println("listenButtonClicked");
        		prevClap = -100;
            	if (mIsRecording) {
					listenButton.setText("Listen");
					mIsRecording = false;
				} else {
					listenButton.setText("Stop listening");
					mIsRecording = true;
					listen();
				}
            }
        });
        
        Button share_button = (Button) findViewById(R.id.button_save);
        share_button.setOnClickListener(new View.OnClickListener() {
        	@Override
            public void onClick(View v) {
            	System.out.println("saveButtonClicked");
            	Intent sharingIntent = new Intent(Intent.ACTION_SEND);
            	sharingIntent.setType("image/png");
            	sharingIntent.putExtra(Intent.EXTRA_STREAM, picUri);
            	startActivity(Intent.createChooser(sharingIntent, "Share image using"));
            }
        });
		
	}
	
	public void listen() {
		recorder.startRecording();

		tarsosFormat = new be.hogent.tarsos.dsp.AudioFormat(
						(float)SAMPLE_RATE, // sample rate
						16, // bit depth
						1, // channels
						true, // signed samples?
						false // big endian?
						);

		Thread listeningThread = new Thread(new Runnable() {

			@Override
			public void run() {
				while (mIsRecording) {
					int bufferReadResult =
							recorder.read(buffer, 0, buffer.length);
					AudioEvent audioEvent =
							new AudioEvent(
									tarsosFormat,
									bufferReadResult);
					audioEvent.setFloatBufferWithByteBuffer(buffer);
					mPercussionOnsetDetector.process(audioEvent);
				}
				recorder.stop();
			}

		});

		listeningThread.start();
	}

	PictureCallback jpegCallback = new PictureCallback() {
        @Override
        public void onPictureTaken(byte[] data, Camera camera) {
        	System.out.println("entering jpegCallback()");
            pictureFile = getOutputMediaFile();
            picUri = getOutputMediaFileUri();
            if (pictureFile == null) {
                return;
            }
            try {
                FileOutputStream fos = new FileOutputStream(pictureFile);
                fos.write(data);
                fos.close();
                System.out.println("File should be saved at this point");
            } catch (FileNotFoundException e) {
            	System.out.println("FileNotFoundException in jpegCallback");
            } catch (IOException e) {
            	System.out.println("IOException in jpegCallback");
            }
        }
    };
    
    private static Uri getOutputMediaFileUri(){
        return Uri.fromFile(getOutputMediaFile());
    }
    
    @SuppressLint("SimpleDateFormat")
	private static File getOutputMediaFile() {
    	System.out.println("entering getOutputMediaFile()");
        File mediaStorageDir = new File(
                Environment
                        .getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES),
                "MyCameraApp");
        if (!mediaStorageDir.exists()) {
            if (!mediaStorageDir.mkdirs()) {
                Log.d("MyCameraApp", "failed to create directory");
                return null;
            }
        }
        // Create a media file name
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss")
                .format(new Date());
        File mediaFile;
        mediaFile = new File(mediaStorageDir.getPath() + File.separator
                + "IMG_" + timeStamp + ".jpg");

        return mediaFile;
    }
    
	
	
 
	
	/** A safe way to get an instance of the Camera object. */

	public static Camera getCameraInstance(){
	    Camera c = null;
	    try {
	        c = Camera.open();
	    }
	    catch (Exception e){
	    	Log.d(TAG, "Error in getCameraInstance: " + e.getMessage());
	        // Camera is not available (in use or does not exist)
	    }
	    return c; // returns null if camera is unavailable
	}
	
	
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.activity_main, menu);
		return true;
	}

	@Override
	protected void onResume() {
		super.onResume();
		System.out.println("onResume()");
		mCamera = getCameraInstance();
		mPreview = new CameraPreview(context, mCamera);
        FrameLayout preview = (FrameLayout) findViewById(R.id.camera_preview);
        preview.addView(mPreview);
        
	}
	
    @Override
    protected void onPause() {
        super.onPause();
        System.out.println("onPause()");
        if (mCamera!=null) {
        	mCamera.stopPreview();
        	mCamera.release();
        }
    }
    
    @Override
    protected void onStop() {
    	super.onStop();
    	System.out.println("onStop()");
    
    }
    
    @Override
    protected void onStart() {
    	super.onStart();
    	System.out.println("onStart()");
    }
    
    @Override
    protected void onDestroy() {
    	super.onDestroy();
    	System.out.println("onDestroy()");
    }
}

